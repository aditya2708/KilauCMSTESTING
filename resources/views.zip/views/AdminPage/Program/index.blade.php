@extends('AdminPage.App.master')

@section('style')
    <style>
        #editor-container {
            min-height: 150px;
            max-height: 500px;
            overflow-y: auto;
        }
    </style>
@endsection

@section('content')
    <div class="container">
        <div class="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Data Timeline</h4>
                                <button class="btn btn-primary btn-round ms-auto" data-toggle="modal"
                                    data-target="#createTimelineModal">
                                    <i class="fa fa-plus"></i> Tambah Data
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="progaram-table" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Judul Program</th>
                                            <th>Program Yang Berhasil Dijalankan</th>
                                            <th>Deskripsi</th>
                                            <th>Status</th>
                                            <th>Foto Program</th>
                                            <th>Foto Thumbnail</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($program as $item)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>{{ $item->judul }}</td>
                                                <td>{{ $item->program_yang_berhasil_dijalankan }} %</td>
                                                <td>{{ $item->deskripsi }}</td>
                                                <td>
                                                    <span
                                                        class="badge {{ $item->status_program == 'Aktif' ? 'badge-success' : 'badge-danger' }}">
                                                        {{ $item->status_program }}
                                                    </span>
                                                </td>
                                                <td>
                                                    @if ($item->foto_image)
                                                        <div class="form-group">
                                                            <div>
                                                                @foreach ($item->foto_image as $image)
                                                                    <img src="{{ asset('storage/' . $image) }}"
                                                                        alt="Foto Program" width="100" height="auto"
                                                                        style="margin-right: 10px;">
                                                                @endforeach
                                                            </div>
                                                        </div>
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($item->thumbnail_image)
                                                        <img src="{{ Storage::url($item->thumbnail_image) }}"
                                                            alt="Program Image" style="width: 100px; height: auto;">
                                                    @else
                                                        No Image
                                                    @endif
                                                </td>
                                                <td>
                                                    <div class="btn-group gap-2" role="group">
                                                        <!-- Tombol Edit -->
                                                        <button
                                                            class="btn btn-warning btn-sm rounded-circle p-2 btnEditProgram"
                                                            data-toggle="modal" data-target="#editProgramModal"
                                                            data-id="{{ $item->id }}" data-judul="{{ $item->judul }}"
                                                            data-deskripsi="{{ $item->deskripsi }}"
                                                            data-presentase="{{ $item->program_yang_berhasil_dijalankan }}"
                                                            data-thumbnail="{{ Storage::url($item->thumbnail_image) }}"
                                                            data-file_galeri="{{ json_encode($item->foto_image) }}"
                                                            title="Edit">
                                                            <i class="fas fa-edit"></i>
                                                        </button>

                                                        <!-- Tombol Delete -->
                                                        <button class="btn btn-danger btn-sm rounded-circle p-2"
                                                            data-toggle="modal"
                                                            data-target="#deleteProgramModal{{ $item->id }}"
                                                            title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>

                                                        <!-- Tombol Ubah Status -->
                                                        <button class="btn btn-info btn-sm rounded-circle p-2"
                                                            data-toggle="modal"
                                                            data-target="#statusModal{{ $item->id }}"
                                                            title="Ubah Status">
                                                            <i class="fas fa-exchange-alt"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>

                                            <!-- Modal Delete Program -->
                                            <div class="modal fade" id="deleteProgramModal{{ $item->id }}"
                                                tabindex="-1" role="dialog"
                                                aria-labelledby="deleteProgramModalLabel{{ $item->id }}"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <form action="{{ route('program.delete', $item->id) }}"
                                                            method="POST">
                                                            @csrf
                                                            @method('DELETE')
                                                            <div class="modal-header">
                                                                <h5 class="modal-title"
                                                                    id="deleteProgramModalLabel{{ $item->id }}">Hapus
                                                                    Galeri</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Apakah Anda yakin ingin menghapus galeri ini?
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Tutup</button>
                                                                <button type="submit" class="btn btn-danger">Hapus</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Modal Toggle Status -->
                                            <div class="modal fade" id="statusModal{{ $item->id }}" tabindex="-1"
                                                role="dialog" aria-labelledby="statusModalLabel{{ $item->id }}"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <form action="{{ route('program.toggleStatus', $item->id) }}"
                                                            method="POST">
                                                            @csrf
                                                            <div class="modal-header">
                                                                <h5 class="modal-title"
                                                                    id="statusModalLabel{{ $item->id }}">
                                                                    Ubah Status Program
                                                                </h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Pilih status untuk program:
                                                                    <strong>{{ $item->judul }}</strong>.
                                                                </p>
                                                                <div class="form-group">
                                                                    <label>Status</label>
                                                                    <select name="status_program" class="form-control">
                                                                        <option value="1"
                                                                            {{ $item->status_program == 1 ? 'selected' : '' }}>
                                                                            Aktif
                                                                        </option>
                                                                        <option value="2"
                                                                            {{ $item->status_program == 2 ? 'selected' : '' }}>
                                                                            Tidak Aktif
                                                                        </option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Tutup</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Simpan</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Edit Program -->
    <div class="modal fade" id="editProgramModal" tabindex="-1" role="dialog" aria-labelledby="editProgramModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="editProgramForm" action="" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-header">
                        <h5 class="modal-title" id="editProgramModalLabel">Edit Program</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- ID Program -->
                        <input type="hidden" id="editProgramId" name="id">

                        <!-- Judul Program -->
                        <div class="form-group">
                            <label for="judul">Judul Program</label>
                            <input type="text" class="form-control" id="editJudul" name="judul" required>
                        </div>

                        <!-- Deskripsi -->
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <textarea class="form-control" id="editDeskripsi" name="deskripsi" required></textarea>
                        </div>

                        <!-- Presentase Program -->
                        <div class="form-group">
                            <label for="program_yang_berhasil_dijalankan">Presentase Program</label>
                            <input type="number" name="program_yang_berhasil_dijalankan" class="form-control"
                                min="0" max="100" step="1" id="editPresentase" required
                                placeholder="Masukkan persentase antara 0-100">
                        </div>

                        <!-- Thumbnail -->
                        <div class="form-group">
                            <label>Thumbnail Program</label>
                            <input type="file" name="thumbnail_image" id="thumbnail_image" class="form-control">
                            <div id="editImagePreviewNewThumbnail" class="mt-2">
                                <!-- Preview thumbnail baru -->
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Foto Program</label>
                            <input type="file" name="foto_image[]" class="form-control" id="foto_image" multiple>

                            <!-- Preview Foto Program Lama -->
                            <div id="editImagePreviewOld" class="mt-2">
                                <!-- Gambar lama akan dimasukkan di sini oleh JavaScript -->
                            </div>

                            <!-- Preview Foto Program Baru -->
                            <div id="editImagePreviewNew" class="mt-2">
                                <!-- Gambar baru yang dipilih akan muncul di sini -->
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Create -->
    <div class="modal fade" id="createTimelineModal" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="createProgramForm" action="{{ route('program.create') }}" method="POST"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Program</h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Judul Program</label>
                            <input type="text" name="judul" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Deskripsi</label>
                            <textarea name="deskripsi" class="form-control" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Thumbnail Program</label>
                            <input type="file" name="thumbnail_image" class="form-control">

                        </div>
                        <div class="form-group">
                            <label>Foto Program</label>
                            <input type="file" name="foto_image[]" class="form-control" id="foto_image" multiple>
                            <div id="imagePreview" class="mt-2">
                                <!-- Preview images will be shown here -->
                            </div>
                        </div>
                        <!-- Field Presentase -->
                        <div class="form-group">
                            <label>Presentase Program</label>
                            <input type="number" name="program_yang_berhasil_dijalankan" class="form-control"
                                min="0" max="100" step="1" required
                                placeholder="Masukkan persentase antara 0-100">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {
            $('#progaram-table').DataTable();

            // Event Listener untuk tombol Edit Program
            $('.btnEditProgram').click(function() {
                var id = $(this).data('id');
                var judul = $(this).data('judul');
                var deskripsi = $(this).data('deskripsi');
                var presentase = $(this).data('presentase');
                var thumbnail = $(this).data('thumbnail');
                var fileGaleri = $(this).data('file_galeri'); // Ambil data gambar lama

                // Set nilai di modal
                $('#editProgramId').val(id);
                $('#editJudul').val(judul);
                $('#editDeskripsi').val(deskripsi);
                $('#editPresentase').val(presentase);

                // Set URL Form
                var editUrl = "{{ route('program.edit', ':id') }}".replace(':id', id);
                $('#editProgramForm').attr('action', editUrl);

                // Tampilkan Thumbnail jika ada
               /*  $('#editImagePreviewNewThumbnail').html('');
                if (thumbnail && thumbnail !== "null") {
                    $('#editImagePreviewNewThumbnail').append(
                        '<img src="' + thumbnail + '" class="img-thumbnail" width="100" style="margin-right: 10px;">'
                    );
                } */

                // Reset Preview Gambar Lama
                $('#editImagePreviewOld').html('');

                // Jika ada gambar lama, tampilkan
                if (fileGaleri && fileGaleri !== "null") {
                    var images = JSON.parse(fileGaleri);
                    images.forEach(function(image) {
                        $('#editImagePreviewOld').append(
                            '<img src="' + '/storage/' + image +
                            '" class="img-thumbnail" width="100" style="margin-right: 10px;">'
                        );
                    });
                }

                // Reset Preview Gambar Baru
                $('#editImagePreviewNew').html('');
            });

            // Menampilkan preview thumbnail baru saat file dipilih
            $('#thumbnail_image').on('change', function() {
                var file = this.files[0];
                $('#editImagePreviewNewThumbnail').html('');

                if (file) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#editImagePreviewNewThumbnail').append(
                            '<img src="' + e.target.result +
                            '" class="img-thumbnail" width="100" style="margin-right: 10px;">'
                        );
                    };
                    reader.readAsDataURL(file);
                }
            });

            // Menampilkan preview gambar baru saat file dipilih
            $('#foto_image').on('change', function() {
                var files = this.files;
                $('#editImagePreviewNew').html('');

                for (var i = 0; i < files.length; i++) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#editImagePreviewNew').append(
                            '<img src="' + e.target.result +
                            '" class="img-thumbnail" width="100" style="margin-right: 10px;">'
                        );
                    };
                    reader.readAsDataURL(files[i]);
                }
            });
        });
    </script>
@endsection

