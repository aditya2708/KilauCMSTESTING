<!-- Sidebar -->
<div class="sidebar" data-background-color="light">
    <div class="sidebar-logo">
        <div class="logo-header" data-background-color="light">
            <a href="index.html" class="logo">
                <img src="{{ asset('assets_admin/img/LogoKilau2.png') }}" alt="Kilau" class="navbar-brand"
                    height="50" width="50" />
                <p style="color: black; padding-top: 10px; font-weight: 500;">Kilau Indonesia</p>
            </a>
            <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                    <i class="gg-menu-right" style="color: black;"></i>
                </button>
                <button class="btn btn-toggle sidenav-toggler">
                    <i class="gg-menu-left" style="color: black;"></i>
                </button>
            </div>
            <button class="topbar-toggler more">
                <i class="gg-more-vertical-alt" style="color: black;"></i>
            </button>
        </div>
    </div>
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <ul class="nav nav-primary">
                <!-- Home Section -->
                <li
                    class="nav-item {{ Request::routeIs('dashboard') || Request::routeIs('settingsmenu') ? 'active' : '' }} nav-category">
                    <p>Home</p>
                </li>
                <li class="nav-item {{ Request::routeIs('dashboard') ? 'active' : '' }}">
                    <a href="{{ route('dashboard') }}">
                        <i class="fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="nav-item {{ Request::routeIs('settingsmenu') ? 'active' : '' }}">
                    <a href="{{ route('settingsmenu') }}">
                        <i class="fas fa-cog"></i>
                        <p>Settings Menu</p>
                    </a>
                </li>

                <li
                    class="nav-item {{ Request::routeIs('testimoni') || Request::routeIs('faq') || Request::routeIs('mitra') || Request::routeIs('kontak') || Request::routeIs('berita') || Request::routeIs('profile-kilau') ? 'active' : '' }} nav-category">
                    <p>Ruang Kerja</p>
                </li>

                <li
                    class="nav-item {{ Request::routeIs('profile-kilau') || Request::routeIs('profil.tentangkami') || Request::routeIs('profil.homekilau') || Request::routeIs('profil.iklankilau') || Request::routeIs('profil.struktur') || Request::routeIs('profil.sejarah') || Request::routeIs('profil.visimisi') || Request::routeIs('profil.pimpinan') ? 'active' : '' }} dropdown">
                    <a href="#" class="nav-link dropdown-toggle" id="navbarDropdownProfile" role="button"
                        data-toggle="collapse" data-target="#profileKilauCollapse" aria-expanded="false"
                        aria-controls="profileKilauCollapse">
                        <i class="fas fa-info-circle"></i>
                        <p>Profile Kilau</p>
                    </a>
                    <div class="collapse {{ Request::routeIs('profil.tentangkami') || Request::routeIs('profil.homekilau') || Request::routeIs('profil.iklankilau') || Request::routeIs('profil.struktur') || Request::routeIs('profil.sejarah') || Request::routeIs('profil.visimisi') || Request::routeIs('profil.pimpinan') ? 'show' : '' }}"
                        id="profileKilauCollapse">
                        <ul class="nav nav-collapse">
                            <li>
                                <a href="{{ route('profil.tentangkami') }}"
                                    class="{{ Request::routeIs('profil.tentangkami') ? 'active' : '' }}"
                                    style="{{ Request::routeIs('profil.tentangkami') ? 'color: #1572E8; font-weight: bold;' : '' }}">
                                    <span class="sub-item">Tentang Kami</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('profil.pimpinan') }}"
                                    class="{{ Request::routeIs('profil.pimpinan') ? 'active' : '' }}"
                                    style="{{ Request::routeIs('profil.pimpinan') ? 'color: #1572E8; font-weight: bold;' : '' }}">
                                    <span class="sub-item">Pimpinan Kilau</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('profil.iklankilau') }}"
                                    class="{{ Request::routeIs('profil.iklankilau') ? 'active' : '' }}"
                                    style="{{ Request::routeIs('profil.iklankilau') ? 'color: #1572E8; font-weight: bold;' : '' }}">
                                    <span class="sub-item">Iklan Kilau</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('profil.homekilau') }}"
                                    class="{{ Request::routeIs('profil.homekilau') ? 'active' : '' }}"
                                    style="{{ Request::routeIs('profil.homekilau') ? 'color: #1572E8; font-weight: bold;' : '' }}">
                                    <span class="sub-item">Home Kilau</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('profil.struktur') }}"
                                    class="{{ Request::routeIs('profil.struktur') ? 'active' : '' }}"
                                    style="{{ Request::routeIs('profil.struktur') ? 'color: #1572E8; font-weight: bold;' : '' }}">
                                    <span class="sub-item">Struktur</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('profil.sejarah') }}"
                                    class="{{ Request::routeIs('profil.sejarah') ? 'active' : '' }}"
                                    style="{{ Request::routeIs('profil.sejarah') ? 'color: #1572E8; font-weight: bold;' : '' }}">
                                    <span class="sub-item">Sejarah</span>
                                </a>
                            </li>

                            <li>
                                <a href="{{ route('profil.visimisi') }}"
                                    class="{{ Request::routeIs('profil.visimisi') ? 'active' : '' }}"
                                    style="{{ Request::routeIs('profil.visimisi') ? 'color: #1572E8; font-weight: bold;' : '' }}">
                                    <span class="sub-item">Visi dan Misi</span>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>

                <li class="nav-item {{ Request::routeIs('timeline') ? 'active' : '' }}">
                    <a href="{{ route('timeline') }}">
                        <i class="fas fa-hourglass"></i>
                        <p>Timeline Kilau</p>
                    </a>
                </li>

                <li class="nav-item {{ Request::routeIs('berita') ? 'active' : '' }}">
                    <a href="{{ route('berita') }}">
                        <i class="fas fa-newspaper"></i>
                        <p>Berita</p>
                    </a>
                </li>

                <li class="nav-item {{ Request::routeIs('program') ? 'active' : '' }}">
                    <a href="{{ route('program') }}">
                        <i class="fas fa-tasks"></i>
                        <p>Program</p>
                    </a>
                </li>     
                
                <li class="nav-item {{ Request::routeIs('galeryAdmin') ? 'active' : '' }}">
                    <a href="{{ route('galeryAdmin') }}">
                        <i class="fas fa-image"></i>
                        <p>Galeri</p>
                    </a>
                </li>
                                 

                <li class="nav-item {{ Request::routeIs('document') ? 'active' : '' }}">
                    <a href="{{ route('document') }}">
                        <i class="fas fa-file-alt"></i>
                        <p>Dokumen</p>
                    </a>
                </li>

                <li class="nav-item {{ Request::routeIs('testimoni') ? 'active' : '' }}">
                    <a href="{{ route('testimoni') }}">
                        <i class="fas fa-comments"></i>
                        <p>Testimoni</p>
                    </a>
                </li>

                <li class="nav-item {{ Request::routeIs('faq') ? 'active' : '' }}">
                    <a href="{{ route('faq') }}">
                        <i class="fas fa-question-circle"></i>
                        <p>FAQ</p>
                    </a>
                </li>

                <li class="nav-item {{ Request::routeIs('mitra') ? 'active' : '' }}">
                    <a href="{{ route('mitra') }}">
                        <i class="fas fa-handshake"></i>
                        <p>Mitra Donatur</p>
                    </a>
                </li>

                <li class="nav-item {{ Request::routeIs('kontak') ? 'active' : '' }}">
                    <a href="{{ route('kontak') }}">
                        <i class="fas fa-fax"></i>
                        <p>Kontak</p>
                    </a>
                </li>          

                {{--  <!-- Logout -->
                <li class="nav-item">
                    <form action="{{ route('logout') }}" method="POST" id="logout-form">
                        @csrf
                        <a href="#"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fas fa-sign-out-alt"></i>
                            <p>Logout</p>
                        </a>
                    </form>
                </li> --}}

                <!-- Kembali ke Dashboard -->
               {{--  <li class="nav-item">
                    <a href="{{ route('dashboardlogin') }}" class="nav-link">
                        <i class="fas fa-sign-in-alt"></i>
                        <p>Kembali ke Dashboard</p>
                    </a>
                </li>     --}}            

            </ul>
        </div>
    </div>
</div>
<!-- End Sidebar -->

<!-- CSS -->
<style>
    .nav-category {
        font-weight: bold;
        color: #5c5c5c;
        font-size: 16px;
        padding: 10px 0;
        text-transform: uppercase;
        margin-top: 20px;
        border-bottom: 2px solid #f0f0f0;
        background-color: #fafafa;
        padding-left: 15px;
        font-family: 'Arial', sans-serif;
    }

    .nav-category p {
        margin: 0;
        padding: 0;
    }

    .nav-item {
        position: relative;
        padding-left: 10px;
        margin-bottom: 10px;
    }

    .nav-item a {
        font-size: 14px;
        font-weight: 400;
        color: #333;
        display: flex;
        align-items: center;
        padding: 12px 20px;
        transition: background-color 0.3s ease;
    }
</style>
