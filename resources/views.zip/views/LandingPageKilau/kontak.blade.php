@extends('App.master')

@section('style')
    <style>
        /* Tambahkan CSS khusus jika diperlukan */
        .contact-section {
            padding: 60px 0;
        }

        .contact-info {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .contact-info h3 {
            color: #1363c6;
            margin-bottom: 20px;
        }

        .contact-info p {
            font-size: 1rem;
            color: #333;
            margin-bottom: 10px;
        }

        .contact-info i {
            color: #1363c6;
            margin-right: 10px;
            font-size: 1.2rem;
        }

        .map-container {
            height: 300px;
            border-radius: 10px;
            overflow: hidden;
            margin-top: 20px;
        }

        .map-container iframe {
            width: 100%;
            height: 100%;
            border: 0;
        }

        .text-section {
            text-align: center; /* Pusatkan teks judul */
        }

        .btn-sejarah {
            background-color: #1363c6; /* Warna tombol */
            color: #fff; /* Warna teks tombol */
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }

        .btn-sejarah:hover {
            background-color: #0e4a9e; /* Warna tombol saat hover */
        }
    </style>
@endsection

@section('content')
    <!-- Hero Start -->
    <div class="container-fluid pt-5 bg-primary hero-header">
        <div class="container pt-5">
            <div class="row g-5 pt-5">
                <!-- Kolom untuk Teks dan Breadcrumb -->
                <div class="col-12 text-center" style="margin-top: 100px !important;">
                    <h1 class="display-4 text-white mb-4">Kontak Kami</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center mb-0">
                            <li class="breadcrumb-item"><a class="text-white" href="#">Beranda</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="#">Profil</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Kontak Kami</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->

    <!-- Kontak Start -->
    <div class="container-fluid py-5 contact-section">
        <div class="container py-5">
            <!-- Informasi Kontak -->
            <div class="row g-5">
                <div class="col-12 text-section wow fadeIn" data-wow-delay="0.1s">
                    <div class="btn btn-sm border rounded-pill text-primary px-3 mb-3">Kontak</div>
                    <h1 class="mb-4">{{ $kontakMenu->judul }}</h1>
                    <p class="mb-4">{{ $kontakMenu->subjudul }}</p>
                </div>
            </div>

            <!-- Daftar Kantor Cabang -->
            <div class="row g-5">
                @if (count($kontaks) > 0)
                    @foreach ($kontaks as $kontak)
                        <div class="col-lg-6">
                            <div class="contact-info">
                                <h3>{{ $kontak->nama_kacab }}</h3>
                                <p><i class="fas fa-map-marker-alt"></i> {{ $kontak->alamat }}</p>
                                <p><i class="fas fa-phone"></i> {{ $kontak->telephone }}</p>
                                <p><i class="fas fa-envelope"></i> {{ $kontak->email }}</p>
                                <div class="map-container">
                                    <div id="map-preview{{ $kontak->id }}" style="width: 100%; height: 300px;"></div>
                                    <input type="hidden" name="maplink" id="maplink{{ $kontak->id }}" value="{{ $kontak->maplink }}">
                                </div>
                            </div>
                        </div>
                    @endforeach
                @else
                    <div class="col-12 text-center">
                        <p>Tidak ada data kontak yang tersedia.</p>
                    </div>
                @endif
            </div>
        </div>
    </div>
    <!-- Kontak End -->
@endsection

@section('scripts')
    <!-- Memuat Google Maps API hanya sekali -->
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAxYq6wdf9FuMW3AUI7GKEgO9SlHvaht8c&region=ID&language=id&libraries=places"></script>

    <script>
        $(document).ready(function() {
            // Function untuk menampilkan peta berdasarkan koordinat
            function initMap(mapPreviewId, maplink) {
                // Ekstrak latitude dan longitude dari maplink
                var coords = maplink.split('=')[1].split(',');
                var latitude = parseFloat(coords[0]);
                var longitude = parseFloat(coords[1]);
    
                // Initialize map
                var mapContainer = document.getElementById(mapPreviewId);
                var map = new google.maps.Map(mapContainer, {
                    zoom: 14,
                    center: { lat: latitude, lng: longitude }
                });
    
                // Add marker at the location
                var marker = new google.maps.Marker({
                    position: { lat: latitude, lng: longitude },
                    map: map
                });
    
                // Tambahkan event listener untuk membuka Google Maps saat marker diklik
                marker.addListener('click', function() {
                    window.open(maplink, '_blank'); // Buka URL Google Maps di tab baru
                });
    
                console.log("Peta berhasil ditampilkan!"); // Debug: cek apakah peta berhasil ditampilkan
            }
    
            // Inisialisasi peta untuk setiap kontak
            @if (count($kontaks) > 0)
                @foreach ($kontaks as $kontak)
                    initMap('map-preview{{ $kontak->id }}', '{{ $kontak->maplink }}');
                @endforeach
            @endif
        });
    </script>
@endsection