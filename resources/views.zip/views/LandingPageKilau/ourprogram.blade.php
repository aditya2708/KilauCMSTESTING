<style>
    .program-card {
        border: none;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    .program-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }

    .program-img {
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        height: 180px;
        object-fit: cover;
    }

    .card-body {
        display: flex;
        flex-grow: 1;
        /* Memastikan konten dalam card mengisi ruang yang tersedia */
        flex-direction: column;
        justify-content: space-between;
        /* Menjaga jarak antara elemen dalam card */
    }

    /* Modal Styling */
    .modal-content {
        border-radius: 10px;
    }

    .modal-lg {
        max-width: 900px;
    }

    .progress {
        height: 8px;
        border-radius: 10px;
    }

    .progress-bar {
        background-color: #007bff;
    }

    /* Gaya untuk Carousel */
    .carousel-inner img {
        border-radius: 8px;
        object-fit: cover;
        width: 100%;
        height: 300px;
    }

    /* Responsiveness */
    @media (max-width: 768px) {
        .container {
            padding: 0 15px;
        }

        .col-md-6 {
            width: 100% !important;
            flex: 0 0 100%;
        }
    }
</style>

<!-- Programs Section Start -->
<div class="container-fluid py-5">
    <div class="container py-5">
        <!-- Judul Section -->
        <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 500px">
            <h1 class="mb-4">{{ $programMenu->judul }}</h1>
            <p class="lead">{{ $programMenu->subjudul }}</p>
        </div>

        <!-- Cards Program -->
        <div class="row g-4 py-5">
            @foreach ($programs as $program)
                <div class="col-lg-3 col-md-6">
                    <div class="card program-card">
                        <img src="{{ asset('storage/' . $program->thumbnail_image) }}" class="card-img-top program-img"
                            alt="{{ $program->judul }}">

                        <div class="card-body text-center">
                            <h5 class="card-title">{{ $program->judul }}</h5>
                            <p class="card-text text-muted">
                                {{ \Illuminate\Support\Str::limit($program->deskripsi, 30) }}</p>

                            <!-- Progress Bar -->
                            <div class="progress mt-3">
                                <div class="progress-bar" role="progressbar"
                                    style="width: {{ $program->program_yang_berhasil_dijalankan }}%;"
                                    aria-valuenow="{{ $program->program_yang_berhasil_dijalankan }}" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                            </div>
                            <p class="small mt-2">{{ $program->program_yang_berhasil_dijalankan }}% program telah berhasil dijalankan</p>
                            <button class="btn btn-primary mt-2 open-modal" data-id="program-modal{{ $program->id }}">
                                Lihat Detail
                            </button>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
<!-- Programs Section End -->

<!-- Modal Program -->
@foreach ($programs as $program)
    <div class="modal fade" id="program-modal{{ $program->id }}" tabindex="-1" aria-labelledby="modalLabel{{ $program->id }}" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel{{ $program->id }}">{{ $program->judul }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Carousel Gambar Dokumentasi -->
                    <div id="carousel{{ $program->id }}" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            @foreach ($program->foto_image as $image)
                                <div class="carousel-item @if ($loop->first) active @endif">
                                    <img src="{{ asset('storage/' . $image) }}" class="d-block w-100" alt="Dokumentasi">
                                </div>
                            @endforeach
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carousel{{ $program->id }}" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carousel{{ $program->id }}" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        </button>
                    </div>

                    <p class="mt-3">{{ $program->deskripsi }}</p>

                    <!-- Statistik Program -->
                    <div class="progress mt-3">
                        <div class="progress-bar" role="progressbar"
                            style="width: {{ $program->program_yang_berhasil_dijalankan }}%;"
                            aria-valuenow="{{ $program->program_yang_berhasil_dijalankan }}" aria-valuemin="0"
                            aria-valuemax="100"></div>
                    </div>
                    <p class="small mt-2">{{ $program->program_yang_berhasil_dijalankan }}% program telah berhasil dijalankan</p>
                </div>
            </div>
        </div>
    </div>
@endforeach
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Menggunakan event listener pada tombol "Lihat Detail"
        const buttons = document.querySelectorAll('.open-modal');

        buttons.forEach(button => {
            button.addEventListener('click', function () {
                const programId = this.getAttribute('data-id');  // Dapatkan ID modal yang sesuai
                const modalTarget = document.getElementById(programId); // Cari modal dengan ID yang sesuai

                // Menampilkan modal yang sesuai
                const modal = new bootstrap.Modal(modalTarget);
                modal.show();
            });
        });
    });
</script>






