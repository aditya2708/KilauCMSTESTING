@extends('App.master')

@section('style')
    <style>
        /* Tambahkan CSS khusus jika diperlukan */
        .blog-section {
            padding: 60px 0;
        }

        .blog-details {
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .blog-details .post-img img {
            border-radius: 10px;
            width: 100%;
            height: auto;
        }

        .blog-details .title {
            color: #1363c6;
            margin-top: 20px;
            margin-bottom: 15px;
        }

        .blog-details .meta-top {
            margin-bottom: 20px;
        }

        .blog-details .meta-top ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .blog-details .meta-top ul li {
            display: inline-block;
            margin-right: 15px;
            color: #666;
            font-size: 0.9rem;
        }

        .blog-details .meta-top ul li i {
            margin-right: 5px;
            color: #1363c6;
        }

        .blog-details .content p {
            font-size: 1rem;
            line-height: 1.8;
            color: #333;
            text-align: justify;
        }

        .search-section {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .search-section h4 {
            color: #1363c6;
            margin-bottom: 20px;
        }

        .search-section .form-control {
            border-radius: 20px;
        }

        .search-section .btn-primary {
            border-radius: 20px;
            background-color: #1363c6;
            border: none;
            transition: background-color 0.3s ease;
        }

        .search-section .btn-primary:hover {
            background-color: #0e4a9e;
        }

        /* Tambahkan styling untuk berita terkini */
        .recent-berita {
            margin-top: 20px;
        }

        .recent-berita .card {
            border: none;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 15px;
        }

        .recent-berita .card img {
            border-radius: 10px 10px 0 0;
        }

        .recent-berita .card-body {
            padding: 15px;
        }

        .recent-berita .card-title {
            font-size: 1rem;
            color: #1363c6;
            margin-bottom: 10px;
        }

        .recent-berita .card-text {
            font-size: 0.9rem;
            color: #666;
        }
    </style>
@endsection

@section('content')
    <!-- Hero Start -->
    <div class="container-fluid pt-5 bg-primary hero-header">
        <div class="container pt-5">
            <div class="row g-5 pt-5">
                <!-- Kolom untuk Teks dan Breadcrumb -->
                <div class="col-12 text-center" style="margin-top: 100px !important;">
                    <h1 class="display-4 text-white mb-4" id="judul-berita">Berita Kami</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center mb-0">
                            <li class="breadcrumb-item"><a class="text-white" href="/">Beranda</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Berita</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->

    <!-- Blog Section Start -->
    <div class="container-fluid py-5 blog-section">
        <div class="container py-5">
            <div class="row g-5">
                <!-- Bagian Berita Detail -->
                <div class="col-lg-8">
                    <section id="blog-details" class="blog-details section">
                        <article class="article">
                            <!-- Carousel Gambar Berita -->
                            <div class="post-img">
                                <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-inner" id="carousel-berita">
                                        <!-- Gambar akan dimuat lewat AJAX -->
                                    </div>
                                    <button class="carousel-control-prev" type="button"
                                        data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button"
                                        data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>
                                </div>
                            </div><!-- End Carousel -->

                            <h2 class="title" id="judul-detail"></h2>

                            <div class="meta-top">
                                <ul>
                                    <li class="d-flex align-items-center"><i class="bi bi-person"></i> Kilau Indonesia</li>
                                    <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <time
                                            id="tanggal-detail"></time></li>
                                </ul>
                            </div><!-- End meta top -->

                            <div class="content" id="konten-detail">
                                <!-- Konten berita akan dimuat lewat AJAX -->
                            </div><!-- End post content -->
                        </article>
                    </section><!-- /Blog Details Section -->
                </div>

                <!-- Sidebar Berita Terkini -->
                <div class="col-lg-4">
                    <div class="recent-berita">
                        <h4>Berita Terkini</h4>
                        <div id="recent-berita-container">
                            <!-- Berita terkini akan dimuat lewat AJAX -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Blog Section End -->
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {
            let beritaId = window.location.pathname.split("/").pop(); // Ambil ID dari URL

            function convertHashtagsToLinks(text) {
                return text.replace(/#(\w+)/g, function(match, tag) {
                    let encodedTag = encodeURIComponent(tag);
                    return `<a href="https://www.google.com/search?q=${encodedTag}" class="text-primary" target="_blank">${match}</a>`;
                });
            }

            function loadBerita() {
                $.ajax({
                    url: `https://berbagipendidikan.org/api/berita/${beritaId}`,
                    type: "GET",
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            let berita = response.data;

                            $("#judul-detail").text(berita.judul);
                            $("#tanggal-detail").text(berita.tanggal);

                            // Proses hashtag sebelum menampilkan konten
                            let kontenDikonversi = convertHashtagsToLinks(berita.konten);
                            $("#konten-detail").html(kontenDikonversi);

                            let gambarHtml = "";
                            let baseUrl = "https://berbagipendidikan.org";

                            if (berita.foto) {
                                gambarHtml +=
                                    `<div class="carousel-item active"><img src="${baseUrl}${berita.foto}" class="d-block w-100"></div>`;
                            }
                            $("#carousel-berita").html(gambarHtml);
                        }
                    }
                });
            }

            function loadBeritaTerkini() {
                $.ajax({
                    url: "https://berbagipendidikan.org/api/berita?page=1&per_page=4",
                    type: "GET",
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            let beritaHtml = "";
                            response.data.forEach(function(berita) {
                                beritaHtml += `
                                <div class="card">
                                    <img src="https://berbagipendidikan.org${berita.foto}" class="card-img-top">
                                    <div class="card-body">
                                        <h5 class="card-title"><a href="/berita/${berita.id}">${berita.judul}</a></h5>
                                    </div>
                                </div>
                            `;
                            });
                            $("#recent-berita-container").html(beritaHtml);
                        }
                    }
                });
            }

            loadBerita();
            loadBeritaTerkini();
        });
    </script>
@endsection
