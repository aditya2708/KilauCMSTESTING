@extends('App.master')

@section('style')
    <style>
        /* Media Query untuk Mobile */
        @media (max-width: 768px) {
            .container {
                padding: 0 15px;
            }

            #berita-container {
                flex-direction: column;
                overflow-x: auto;
            }

            .col-lg-4,
            .col-md-6 {
                width: 100% !important;
                flex: 0 0 100%;
            }

            .card-title a {
                font-size: 16px;
            }

            .card-text {
                font-size: 12px;
            }
        }

        /* Media Query untuk Tablet */
        @media (max-width: 1024px) {

            .col-lg-4,
            .col-md-6 {
                width: 100% !important;
            }
        }
    </style>
@endsection

@section('content')

    <!-- Hero Start -->
    <div class="container-fluid pt-5 bg-primary hero-header mb-5">
        <div class="container pt-5">
            <!-- Carousel -->
            <div id="heroCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="2000">
                <!-- Indicators -->
                <div class="carousel-indicators" style="bottom: -100px;">
                    @foreach ($homeKilau as $index => $item)
                        <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="{{ $index }}"
                            class="{{ $index == 0 ? 'active' : '' }}" aria-current="{{ $index == 0 ? 'true' : 'false' }}"
                            aria-label="Slide {{ $index + 1 }}"></button>
                    @endforeach
                </div>

                <!-- Slides -->
                <div class="carousel-inner hero-inner">
                    @foreach ($homeKilau as $index => $item)
                        <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                            <div class="row g-5 pt-5">
                                <!-- Kolom Teks -->
                                <div class="col-lg-6 col-12 align-self-center text-center text-lg-start mb-lg-5">
                                    <h1 class="display-4 text-white mb-4">
                                        {{ $item->judul_home }}
                                    </h1>
                                </div>

                                <!-- Kolom Gambar atau Animasi Lottie -->
                                <div class="col-lg-6 col-12 order-1 order-lg-3 ps-3 d-flex justify-content-center">
                                    @if ($item->file_home)
                                        <!-- Tampilkan Gambar Jika Ada -->
                                        <img src="{{ Storage::url($item->file_home) }}" class="img-fluid"
                                            alt="{{ $item->judul_home }}" style="max-width: 100%; height: auto;">
                                    @else
                                        <!-- Tampilkan Animasi Lottie Jika Tidak Ada Gambar -->
                                        <dotlottie-player
                                            src="https://lottie.host/e0a24f8d-7cba-4c46-8167-c7cb86af6595/17K5vHPYIi.lottie"
                                            background="transparent" speed="1" style="max-width: 100%; height: auto;"
                                            loop autoplay>
                                        </dotlottie-player>
                                        {{-- <dotlottie-player
                                            src="https://lottie.host/68b0ea5a-ba38-494e-8dda-d9ecdeffc2a2/eycheMpLtU.lottie"
                                            background="transparent" speed="1" style="max-width: 100%; height: auto;"
                                            loop autoplay>
                                        </dotlottie-player> --}}
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->

    {{-- About Section Start --}}
    @if ($tentangMenu && $tentangMenu->status == 'Aktif')
        <div class="container-fluid py-1">
            <div class="container py-1">
                <!-- Judul Section -->
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <!-- Teks "Tentang Kami" dengan Efek Hover -->
                        <div class="tooltip-container">
                            <h1 class="display-5 fw-bold mb-2 hover-text">{{ $tentangMenu->judul }}</h1>
                        </div>
                        <p class="lead mb-4">
                            {{ $tentangMenu->subjudul }}
                        </p>
                    </div>
                </div>

                <div class="row gx-0 py-3">
                    @foreach ($tentangs as $tentang)
                        <!-- Bagian Teks -->
                        <div class="col-lg-6 d-flex flex-column justify-content-center" data-aos="fade-up"
                            data-aos-delay="200">
                            <div class="content">
                                <h2>{{ $tentang->judul_tentang_kami }}</h2>
                                <p>{{ $tentang->deskripsi }}</p>

                                <!-- Lihat Selengkapnya -->
                                <a href="{{ route('tentangkami.landingpage') }}" class="btn btn-primary mt-2">
                                    Lihat Selengkapnya
                                </a>
                            </div>
                        </div>

                        <!-- Bagian Gambar -->
                        <div class="col-lg-6 d-flex align-items-center" data-aos="zoom-out" data-aos-delay="200">
                            <img src="{{ $tentang->file ? Storage::url($tentang->file) : asset('assets/img/default.jpg') }}"
                                class="img-fluid about-img" alt="Tentang Kami">
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    @endif

    @if ($timelineMenu && $timelineMenu->status == 'Aktif')
        @include('LandingPageKilau.timline_interaktif')
    @endif

    @if ($programMenu && $programMenu->status == 'Aktif')
        @include('LandingPageKilau.ourprogram')
    @endif

    @foreach ($iklanKilau as $item)
        @if ($item->iklanKilauLists->isNotEmpty())
            <!-- Memastikan ada data IklanKilauList yang aktif -->
            <div class="container-fluid bg-primary feature pt-5">
                <div class="container pt-5">
                    <div class="row g-5 align-items-center">
                        <!-- Kolom Kiri: Deskripsi -->
                        <div class="col-lg-6 align-self-center mb-md-5 pb-md-5 wow fadeIn" data-wow-delay="0.3s">
                            <div class="btn btn-sm border rounded-pill text-white px-3 mb-3">
                                Mengapa Memilih Kami
                            </div>
                            <h1 class="text-white mb-4">{{ $item->judul }}</h1>
                            <p class="text-light mb-4">{{ $item->deskripsi }}</p>

                            <!-- Menampilkan semua IklanKilauList tanpa kondisi status aktif -->
                            @foreach ($item->iklanKilauLists as $iklanList)
                                <div class="d-flex align-items-center text-white mb-3">
                                    <div class="btn-sm-square bg-white text-primary rounded-circle me-3">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <span>{{ $iklanList->name }}</span> <!-- Menampilkan name dari IklanKilauList -->
                                </div>
                            @endforeach

                            <!-- Menampilkan IklanKilauList yang aktif -->
                            @foreach ($item->iklanKilauLists as $iklanList)
                                @if ($iklanList->status_iklan_kilau_list == '1')
                                    <!-- Cek jika statusnya aktif -->
                                    <div class="d-flex align-items-center text-white mb-3">
                                        <div class="btn-sm-square bg-white text-primary rounded-circle me-3">
                                            <i class="fa fa-check"></i>
                                        </div>
                                        <span>{{ $iklanList->name }}</span>
                                        <!-- Menampilkan name dari IklanKilauList yang aktif -->
                                    </div>
                                @endif
                            @endforeach

                            <div class="row g-4 pt-3">
                                <div class="col-sm-6">
                                    <div class="d-flex rounded p-3" style="background: rgba(256, 256, 256, 0.1)">
                                        <i class="fa fa-building fa-3x text-white"></i>
                                        <div class="ms-3">
                                            <h2 class="text-white mb-0">{{ $item->jumlah_yayasan }}</h2>
                                            <p class="text-white mb-0">Cabang Yayasan</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="d-flex rounded p-3" style="background: rgba(256, 256, 256, 0.1)">
                                        <i class="fa fa-hand-holding-heart fa-3x text-white"></i>
                                        <div class="ms-3">
                                            <h2 class="text-white mb-0" id="jumlahDonatur">Loading...</h2>
                                            <p class="text-white mb-0">Donatur Mitra Kami</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Kolom Kanan: Animasi Lottie atau Gambar -->
                        <div class="col-lg-6 d-flex justify-content-center align-items-center wow fadeIn"
                            data-wow-delay="0.5s">
                            @if ($item->file)
                                <!-- Jika ada gambar, tampilkan gambar -->
                                <img src="{{ Storage::url($item->file) }}" alt="Home Kilau Image" class="img-fluid"
                                    style="max-width: 350px; margin-left: 50px !important; height: auto;">
                            @else
                                <!-- Jika tidak ada gambar, tampilkan animasi Lottie -->
                                <dotlottie-player
                                    src="https://lottie.host/aad7ce21-732e-4713-b698-1318a30a3e18/xsi4Rvux4O.lottie"
                                    background="transparent" speed="1"
                                    style="max-width: 300px; width: 100%; height: auto;" loop autoplay>
                                </dotlottie-player>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        @endif
    @endforeach

    @if ($beritaMenu && $beritaMenu->status == 'Aktif')
        <!-- Berita Start -->
        <div id="berita-donatur" class="container-fluid py-5">
            <div class="container py-5">
                <!-- Judul Section -->
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <h1 class="display-5 fw-bold mb-2"> {{ $beritaMenu->judul }}</h1>
                        <p class="lead mb-4">
                            {{ $beritaMenu->subjudul }}
                        </p>
                    </div>
                </div>

                <!-- Konten Berita -->
                <div class="row g-4 flex-nowrap overflow-x-auto pb-3 scroll-hidden" id="berita-container">
                    <!-- Data Berita Akan Dimuat Dinamis dengan AJAX -->
                </div><!-- End Row -->

                <!-- Pagination -->
                <div class="row justify-content-center mt-4">
                    <nav aria-label="Page navigation">
                        <ul id="pagination" class="pagination">
                            <!-- Tombol pagination akan dimuat oleh JavaScript -->
                        </ul>
                    </nav>
                </div>
            </div><!-- End Container -->
        </div><!-- End Berita -->
    @endif

    @if ($faqMenu && $faqMenu->status == 'Aktif')
        <!-- FAQs Start -->
        <div class="container-fluid bg-light py-1">
            <div class="container py-1">
                <!-- Judul Section -->
                <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 500px">
                    <h1 class="mb-4">{{ $faqMenu->judul }}</h1>
                    <p class="lead">{{ $faqMenu->subjudul }}</p>
                </div>

                <!-- Konten FAQ -->
                <div class="row">
                    <!-- Kolom Pertama -->
                    <div class="col-lg-6">
                        <div class="accordion" id="accordionFAQ1">
                            @foreach ($faqs->slice(0, ceil($faqs->count() / 2)) as $key => $faq)
                                <div class="accordion-item wow fadeIn" data-wow-delay="0.{{ $key + 1 }}s">
                                    <h2 class="accordion-header" id="heading{{ $key }}">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapse{{ $key }}"
                                            aria-expanded="false" aria-controls="collapse{{ $key }}">
                                            {{ $faq->question }}
                                        </button>
                                    </h2>
                                    <div id="collapse{{ $key }}" class="accordion-collapse collapse"
                                        aria-labelledby="heading{{ $key }}" data-bs-parent="#accordionFAQ1">
                                        <div class="accordion-body">
                                            {{ $faq->answer }}
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>

                    <!-- Kolom Kedua -->
                    <div class="col-lg-6">
                        <div class="accordion" id="accordionFAQ2">
                            @foreach ($faqs->slice(ceil($faqs->count() / 2)) as $key => $faq)
                                <div class="accordion-item wow fadeIn" data-wow-delay="0.{{ $key + 5 }}s">
                                    <h2 class="accordion-header" id="heading{{ $key + ceil($faqs->count() / 2) }}">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse"
                                            data-bs-target="#collapse{{ $key + ceil($faqs->count() / 2) }}"
                                            aria-expanded="false"
                                            aria-controls="collapse{{ $key + ceil($faqs->count() / 2) }}">
                                            {{ $faq->question }}
                                        </button>
                                    </h2>
                                    <div id="collapse{{ $key + ceil($faqs->count() / 2) }}"
                                        class="accordion-collapse collapse"
                                        aria-labelledby="heading{{ $key + ceil($faqs->count() / 2) }}"
                                        data-bs-parent="#accordionFAQ2">
                                        <div class="accordion-body">
                                            {{ $faq->answer }}
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div><!-- End Row -->
            </div><!-- End Container -->
        </div>
    @endif

    @if ($testimoniMenu && $testimoniMenu->status == 'Aktif')
        <!-- Testimonial Start -->
        <div class="container-xxl py-5">
            <div class="container py-5">
                <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 500px">
                    <h1 class="mb-4">{{ $testimoniMenu->judul }}</h1>
                    <p class="lead">{{ $testimoniMenu->subjudul }}</p>
                </div>

                <div class="row g-5 py-5">
                    <!-- Carousel Testimonial -->
                    <div class="col-lg-12 wow fadeIn" data-wow-delay="0.5s">
                        <div class="owl-carousel testimonial-carousel border-start border-primary">
                            @if ($testimonis && $testimonis->count())
                                @foreach ($testimonis as $testimoni)
                                    <div class="testimonial-item ps-5">
                                        <i class="fa fa-quote-left fa-2x text-primary mb-3"></i>
                                        <p class="fs-4">
                                            {{ strip_tags($testimoni->komentar) }}
                                        </p>
                                        <div class="d-flex align-items-center">
                                            <img class="img-fluid flex-shrink-0 rounded-circle"
                                                src="{{ $testimoni->file ? Storage::url($testimoni->file) : asset('images/default.png') }}"
                                                style="width: 60px; height: 60px" />
                                            <div class="ps-3">
                                                <h5 class="mb-1">{{ $testimoni->nama }}</h5>
                                                <span>{{ $testimoni->pekerjaan }}</span>
                                            </div>
                                        </div>
                                        <!-- Tombol untuk Membuka Modal Komentar -->
                                        <button type="button" class="btn btn-primary mt-3" data-bs-toggle="modal"
                                            data-bs-target="#commentModal">
                                            Beri Komentar
                                        </button>
                                    </div>
                                @endforeach
                            @else
                                <p class="text-center">Belum ada testimoni yang aktif.</p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Testimonial End -->
    @endif

    <!-- Modal untuk Komentar -->
    <div class="modal fade" id="commentModal" tabindex="-1" aria-labelledby="commentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="commentModalLabel">Beri Komentar</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="commentForm" action="{{ route('testimonihome.create') }}" method="POST"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="commentName" class="form-label">Nama</label>
                            <input type="text" name="nama" class="form-control" id="commentName"
                                placeholder="Masukkan nama Anda" required>
                        </div>
                        <div class="mb-3">
                            <label for="commentKerja" class="form-label">Pekerjaan</label>
                            <input type="text" name="pekerjaan" class="form-control" id="commentKerja"
                                placeholder="Masukkan pekerjaan Anda (Opsional)">
                        </div>
                        <div class="mb-3">
                            <label for="commentMessage" class="form-label">Komentar</label>
                            <textarea name="komentar" class="form-control" id="commentMessage" rows="3" placeholder="Tulis komentar Anda"
                                required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="commentFile" class="form-label">Upload Gambar (Opsional)</label>
                            <input type="file" name="file" class="form-control" id="commentFile"
                                accept="image/*">
                            <small class="text-muted">Hanya gambar dengan format jpeg, png, jpg, gif, svg yang
                                diterima.</small>
                            <div class="mt-2">
                                <img id="imagePreview" src="#" alt="Pratinjau Gambar"
                                    style="max-width: 50%; display: none;" />
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Kirim Komentar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @if ($mitraMenu && $mitraMenu->status == 'Aktif')
        <!-- Mitra Donatur Start -->
        <div id="mitra-donatur" class="container-fluid bg-light py-2">
            <div class="container py-2">
                <!-- Judul Section -->
                <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 500px">
                    <h1 class="mb-4">{{ $mitraMenu->judul }}</h1>
                    <p class="lead">{{ $mitraMenu->subjudul }}</p>
                </div>

                <!-- Baris Pertama -->
                <div class="row justify-content-center wow fadeIn" data-wow-delay="0.3s">
                    @if ($mitras && $mitras->count())
                        @foreach ($mitras->slice(0, 3) as $mitra)
                            <div class="col-lg-2 col-md-3 col-4 mb-4 text-center">
                                <img src="{{ $mitra->file ? Storage::url($mitra->file) : asset('images/default.png') }}"
                                    class="img-fluid" alt="{{ $mitra->nama_mitra }}">
                            </div>
                        @endforeach
                    @else
                        <p class="text-center">Belum ada mitra donatur yang aktif.</p>
                    @endif
                </div>

                <!-- Baris Kedua -->
                <div class="row justify-content-center wow fadeIn" data-wow-delay="0.5s">
                    @if ($mitras && $mitras->count() > 3)
                        @foreach ($mitras->slice(3, 3) as $mitra)
                            <div class="col-lg-2 col-md-3 col-4 mb-4 text-center">
                                <img src="{{ $mitra->file ? Storage::url($mitra->file) : asset('images/default.png') }}"
                                    class="img-fluid" alt="{{ $mitra->nama_mitra }}">
                            </div>
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
        <!-- Mitra Donatur End -->
    @endif

@endsection

@section('scripts')
    <script src="https://unpkg.com/@dotlottie/player-component@2.7.12/dist/dotlottie-player.mjs" type="module"></script>
    <script>
        $(document).ready(function() {
            // Preview gambar sebelum upload
            $('#commentFile').on('change', function() {
                const file = this.files[0]; // Ambil file yang dipilih
                if (file) {
                    const reader = new FileReader(); // Buat FileReader untuk membaca file
                    reader.onload = function(e) {
                        // Tampilkan pratinjau gambar
                        $('#imagePreview').attr('src', e.target.result).css('display', 'block');
                    };
                    reader.readAsDataURL(file); // Baca file sebagai data URL
                } else {
                    // Reset pratinjau gambar jika file dihapus
                    $('#imagePreview').attr('src', '#').css('display', 'none');
                }
            });
        });

        // JavaScript untuk Efek Hover (Opsional)
        document.querySelector('.tooltip-container').addEventListener('mouseenter', function() {
            const tooltip = this.querySelector('.tooltip');
            tooltip.style.opacity = '1';
            tooltip.style.visibility = 'visible';
        });

        document.querySelector('.tooltip-container').addEventListener('mouseleave', function() {
            const tooltip = this.querySelector('.tooltip');
            tooltip.style.opacity = '0';
            tooltip.style.visibility = 'hidden';
        });

        $(document).ready(function() {
            let currentPage = 1;
            let perPage = 6; // Bisa disesuaikan jumlah berita per halaman

            function loadBerita(page = 1) {
                $.ajax({
                    url: `https://berbagipendidikan.org/api/berita?page=${page}&per_page=${perPage}`,
                    type: "GET",
                    dataType: "json",
                    success: function(response) {
                        if (response.success && response.data.length > 0) {
                            let beritaHtml = "";

                            response.data.forEach(function(berita, index) {
                                let fotoUtama = berita.foto ?
                                    `https://berbagipendidikan.org${berita.foto}` :
                                    "assets/img/no-image.jpg";
                                let foto2 = berita.foto2 ?
                                    `https://berbagipendidikan.org${berita.foto2}` : fotoUtama;
                                let foto3 = berita.foto3 ?
                                    `https://berbagipendidikan.org${berita.foto3}` : fotoUtama;
                                let beritaDetailUrl =
                                    `/berita/${berita.id}`; // Rute menuju halaman detail berita

                                beritaHtml += `
                            <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay="${0.1 * (index + 1)}s" style="flex: 0 0 auto; width: 33.333%;">
                                <article class="card h-100">
                                    <div class="post-img card-img-top">
                                        <div id="carouselBerita${berita.id}" class="carousel slide" data-bs-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="carousel-item active">
                                                    <img src="${fotoUtama}" alt="Foto Berita" class="d-block w-100 img-berita">
                                                </div>
                                                <div class="carousel-item">
                                                    <img src="${foto2}" alt="Foto Berita" class="d-block w-100 img-berita">
                                                </div>
                                                <div class="carousel-item">
                                                    <img src="${foto3}" alt="Foto Berita" class="d-block w-100 img-berita">
                                                </div>
                                            </div>
                                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselBerita${berita.id}" data-bs-slide="prev">
                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                <span class="visually-hidden">Previous</span>
                                            </button>
                                            <button class="carousel-control-next" type="button" data-bs-target="#carouselBerita${berita.id}" data-bs-slide="next">
                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                <span class="visually-hidden">Next</span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <h2 class="title card-title">
                                            <a href="${beritaDetailUrl}">${berita.judul}</a>
                                        </h2>
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="post-meta">
                                                <p class="post-author mb-0">Kilau Indonesia</p>
                                                <p class="post-date mb-0">
                                                    <time datetime="${berita.tanggal}">${formatTanggal(berita.tanggal)}</time>
                                                </p>
                                            </div>
                                        </div>
                                        <p class="card-text">${berita.konten.substring(0, 100)}...</p>
                                    </div>
                                </article>
                            </div>
                        `;
                            });

                            $("#berita-container").html(beritaHtml);
                            generatePagination(response.pagination);
                        } else {
                            $("#berita-container").html(
                                '<p class="text-center">Belum ada berita yang tersedia.</p>');
                        }
                    },
                    error: function() {
                        $("#berita-container").html(
                            '<p class="text-center text-danger">Gagal memuat berita.</p>');
                    }
                });
            }

            function formatTanggal(dateString) {
                let options = {
                    year: "numeric",
                    month: "long",
                    day: "numeric"
                };
                return new Date(dateString).toLocaleDateString("id-ID", options);
            }

            function generatePagination(pagination) {
                let paginationHtml = '';
                let maxVisiblePages = 5;

                if (pagination.current_page > 1) {
                    paginationHtml +=
                        `<li class="page-item"><a class="page-link" href="#" data-page="1">First</a></li>`;
                    paginationHtml +=
                        `<li class="page-item"><a class="page-link" href="#" data-page="${pagination.current_page - 1}">«</a></li>`;
                }

                let startPage = Math.max(1, pagination.current_page - Math.floor(maxVisiblePages / 2));
                let endPage = Math.min(pagination.last_page, startPage + maxVisiblePages - 1);

                for (let i = startPage; i <= endPage; i++) {
                    paginationHtml += `<li class="page-item ${i === pagination.current_page ? 'active' : ''}">
                <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>`;
                }

                if (pagination.current_page < pagination.last_page) {
                    paginationHtml +=
                        `<li class="page-item"><a class="page-link" href="#" data-page="${pagination.current_page + 1}">»</a></li>`;
                    paginationHtml +=
                        `<li class="page-item"><a class="page-link" href="#" data-page="${pagination.last_page}">Last</a></li>`;
                }

                $('#pagination').html(paginationHtml);
            }

            function loadJumlahDonatur() {
                $.ajax({
                    url: "https://kilauindonesia.org/api/donitung?kon=1",
                    type: "GET",
                    dataType: "json",
                    success: function(response) {
                        if (response.message === "success") {
                            $("#jumlahDonatur").text(response.data);
                        } else {
                            $("#jumlahDonatur").text("Gagal Memuat");
                        }
                    },
                    error: function() {
                        $("#jumlahDonatur").text("Error");
                    }
                });
            }

            $(document).on('click', '#pagination a', function(e) {
                e.preventDefault();
                let page = $(this).data('page');
                loadBerita(page);
            });

            loadBerita();
            loadJumlahDonatur();
        });
    </script>
@endsection
