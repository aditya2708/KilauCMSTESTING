@extends('AdminPage.App.master')

@section('style')
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

    <style>
        #createArticleModal .modal-dialog { max-width: 800px; width: 90%; }
        .modal-header { color:#000; border-radius:5px 5px 0 0; }
        .modal-title  { font-size:18px; }
        .modal-footer .btn { padding:10px 15px; font-size:14px; }
        .img-thumb { max-width:120px; max-height:120px; border-radius:5px; }
        .ql-editor img { display:block; width:100%; height:auto; }
        #confirmDeleteModal .modal-dialog { max-width: 500px; } /* ubah jika perlu */
        #confirmDeleteModal .modal-content { border-radius: 8px; }
    </style>
@endsection

@section('content')
<div class="container">
    <div class="page-inner">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    {{-- ========= HEADER ========= --}}
                    <div class="card-header">
                        <div class="d-flex align-items-center w-100">
                            <h4 class="card-title mb-0">Data Artikel</h4>

                            <form id="search-form" class="ms-auto d-flex">
                                <input type="text" id="search" name="search"
                                       class="form-control" placeholder="Cari artikel...">
                            </form>

                            <button class="btn btn-primary btn-round ms-2"
                                    data-toggle="modal" data-target="#createArticleModal">
                                <i class="fa fa-plus"></i> Tambah Artikel
                            </button>
                        </div>
                    </div>

                    {{-- ========= BODY ========= --}}
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="article-table" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Judul</th>
                                        <th>Penulis</th>
                                        <th>Tanggal Pembuatan Artikel</th>
                                        <th>Status Artikel</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="article-body">
                                    {{-- data di-isi Ajax --}}
                                </tbody>
                            </table>
                           @include('AdminPage.Artikel.show')
                        </div>

                        {{-- PAGINATION --}}
                        <div class="pagination-container">
                            <ul id="pagination" class="pagination justify-content-end"></ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Create Data --}}
    <div class="modal fade" id="createArticleModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form id="create-article-form" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Artikel</h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        {{-- Judul --}}
                        <div class="form-group">
                            <label>Judul</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>

                        {{-- Penulis (opsional) --}}
                        <div class="form-group">
                            <label>Penulis</label>
                            <input type="text" name="author" class="form-control"
                                   placeholder="Nama penulis (opsional)">
                        </div>

                        {{-- Konten (Quill) --}}
                        <div class="form-group">
                            <label>Konten</label>
                            <div id="editor-create" style="height:250px;"></div>
                            <input type="hidden" name="content" id="content-input">
                        </div>

                        {{-- Foto utama --}}
                        {{-- <div class="form-group">
                            <label>Foto Thumbnail</label>
                            <input type="file" name="photo" class="form-control" accept="image/*">
                        </div> --}}
                        <div class="form-group">
                            <label>Foto Artikel (boleh lebih dari satu, prefer landscape)</label>
                            <input type="file"
                                name="photo[]"
                                id="photo-input"
                                class="form-control"
                                accept="image/*"
                                multiple>   {{-- <-- multiple! --}}
                        </div>

                        {{-- Preview thumbnail --}}
                        <div id="photo-preview" class="d-flex flex-wrap gap-2"></div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- ========== MODAL EDIT ========= --}}
    <div class="modal fade" id="editArticleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
       <form id="edit-article-form" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <input type="hidden" name="id" id="edit-id">
            <div class="modal-header">
            <h5 class="modal-title">Edit Artikel</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            </div>

            <div class="modal-body">

            <div class="form-group">
                <label>Judul</label>
                <input type="text" name="title" id="edit-title" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Penulis</label>
                <input type="text" name="author" id="edit-author" class="form-control">
            </div>

            <div class="form-group">
                <label>Konten</label>
                <div id="editor-edit" style="height:250px;"></div>
                <input type="hidden" name="content" id="edit-content">
            </div>

            <div class="form-group">
                <label>Tambah Foto (opsional)</label>
                <input type="file" id="edit-photo-input"
                    name="photo[]" class="form-control" accept="image/*" multiple>
            </div>

            {{-- preview lama + baru --}}
            <div id="edit-photo-preview" class="d-flex flex-wrap gap-2"></div>
            </div>

            <div class="modal-footer">
            <button type="button" class="btn btn-secondary force-modal-close">Batal</button>
            <button type="submit" class="btn btn-primary">Perbarui</button>
            </div>
        </form>
        </div>
    </div>
    </div>


</div>
 
@endsection

@section('scripts')
    {{-- Quill --}}
    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
    {{-- SweetAlert2 sudah dimuat di master.blade --}}

<script>
/* ============ GLOBAL AJAX HEADER ============ */
$.ajaxSetup({
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
});

$(function () {

    const fmtID = new Intl.DateTimeFormat('id-ID', {
        day:   '2-digit',
        month: 'long',
        year:  'numeric'
    });

    /* ============ QUILL EDITOR ============ */
    const quill = new Quill('#editor-create', {
        theme: 'snow',
        placeholder: 'Tulis isi artikel...'
    });

    const baseToggleUrl = "{{ url('admin/article-kilau/article/status') }}";

    /* ============ STATE ============ */
    const perPage       = 10;
    let   currentPage   = 1;
    let   currentSearch = '';
    let   allData       = [];   

    /* ============ LOAD PERTAMA ============ */
    fetchArticles();

    /* ----- live search ----- */
    $('#search').keyup(function () {
        currentSearch = $(this).val();
        fetchArticles(1, currentSearch);
    });

    /* ============ SUBMIT CREATE ============ */
    $('#create-article-form').submit(function (e) {
        e.preventDefault();
        $('#content-input').val(quill.root.innerHTML);
        const formData = new FormData(this);

        $.post({
            url: "{{ route('createArticle') }}",
            data: formData,
            processData: false,
            contentType: false,
            success: (res) => {
                $('#createArticleModal').modal('hide');
                this.reset();
                quill.setText('');
                fetchArticles(currentPage, currentSearch);

                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil',
                    text: res.message,
                    timer: 2000,
                    showConfirmButton: false
                });
            },
            error: (xhr) => {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal',
                    text: xhr.responseJSON?.message || 'Terjadi kesalahan.',
                });
            }
        });
    });

    let selectedFiles = [];

    $('#photo-input').on('change', function () {
        const newFiles = [...this.files];
        if (!newFiles.length) return;

        newFiles.forEach(f => {
            const duplicate = selectedFiles.some(
                x => x.name === f.name && x.size === f.size && x.lastModified === f.lastModified
            );
            if (!duplicate) selectedFiles.push(f);
        });

        // rebuild FileList
        const dt = new DataTransfer();
        selectedFiles.forEach(f => dt.items.add(f));
        this.files = dt.files;

        renderPreview();
    });

    /* === thumbnail preview === */
    function renderPreview() {
        const preview = $('#photo-preview').empty();

        selectedFiles.forEach(file => {
            if (!file.type.startsWith('image/')) return;

            const reader = new FileReader();
            reader.onload = e => {
                $('<img>', {
                    src: e.target.result,
                    css: {
                        width: '180px',
                        height: 'auto',
                        objectFit: 'cover',
                        borderRadius: '6px',
                        border: '1px solid #ddd',
                        margin: '0'        // gap diatur flex gap-2
                    }
                }).appendTo(preview);
            };
            reader.readAsDataURL(file);
        });
    }

    /* ---- Tombol delete (SweetAlert confirm) ---- */
    $(document).on('click', '.delete-article', function () {
        const id  = $(this).data('id');
        const row = $(`#row-${id}`);

        Swal.fire({
            title: 'Apakah Anda yakin?',
            text : 'Data yang dihapus tidak dapat dikembalikan!',
            icon : 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor : '#3085d6',
            confirmButtonText : 'Ya, hapus!',
            cancelButtonText  : 'Batal'
        }).then(result => {
            if (result.isConfirmed) {
                $.ajax({
                    url : "{{ route('deleteArticle') }}",
                    type: 'DELETE',
                    data: { id },
                    success: res => {
                        // hapus baris tabel &/atau refresh list
                        row.remove();
                        Swal.fire('Terhapus!', res.message, 'success');
                    },
                    error: () => Swal.fire('Gagal', 'Terjadi kesalahan saat menghapus.', 'error')
                });
            }
        });
    });

    // Update Status Approval
    $(document).on('click', '.toggle-status', function () {
        const id = $(this).data('id');

        Swal.fire({
            icon: 'question',
            title: 'Ubah Status?',
            text : 'Artikel akan di-aktif/non-aktif-kan.',
            showCancelButton: true,
            confirmButtonText: 'Ya, ubah'
        }).then(result => {

            if (!result.isConfirmed) return;

            $.ajax({
                url : `${baseToggleUrl}/${id}`, // ← tambahkan id di runtime
                type: 'POST',                  // form-urlencoded
                data: { _method: 'PATCH' },    // spoof menjadi PATCH
                success: res => {
                    Swal.fire({
                        icon:'success',
                        title:'Berhasil',
                        text : res.message,
                        timer:1500,
                        showConfirmButton:false
                    }).then(() => fetchArticles(currentPage, currentSearch));
                },
                error: xhr => {
                    const msg = xhr.responseJSON?.message ?? 'Gagal mengubah status.';
                    Swal.fire('Error', msg, 'error');
                }
            });
        });
    });

    /* ============ PAGINATION CLICK (delegasi) ============ */
    $(document).on('click', '.page-number', function (e) {
        e.preventDefault();
        currentPage = $(this).data('page');
        renderCurrentPage();
    });

    /* ============ FETCH & CACHE ============ */
    function fetchArticles(page = 1, search = '') {
        $.get("{{ route('article.list') }}", { search }, function (data) {
            allData      = data;   // array of articles
            currentPage  = page;
            renderCurrentPage();
        }).fail(() => Swal.fire('Error', 'Gagal mengambil data artikel.', 'error'));
    }

    /* ============ RENDER PAGE AKTIF ============ */
    function renderCurrentPage() {
        const start    = (currentPage - 1) * perPage;
        const pageData = allData.slice(start, start + perPage);

        renderTable(pageData, start);
        renderPagination(Math.ceil(allData.length / perPage));
    }

    /* ----- table body ----- */
    function renderTable(data, startIndex) {
        let html = '';
        let no   = startIndex + 1;
        const defaultImg = "{{ asset('assets_admin/img/noimage.jpg') }}";

        data.forEach(a => {
            const foto  = a.photo || defaultImg;
            const badge = a.status_artikel === 'Aktif' ? 'badge-success' : 'badge-danger';
 
            const tgl = fmtID.format(new Date(a.created_at));

            html += `
                <tr id="row-${a.id}">
                    <td>${no++}</td>
                    <td>${a.title}</td>
                    <td>${a.author ?? '-'}</td>
                    <td>${tgl}</td>
                   <td>
                        <span class="badge ${badge} d-inline-block text-center"
                            style="min-width:100px; line-height:28px; padding:4px 0;">
                            ${a.status_artikel}
                        </span>
                    </td>
                    <td>
                        <div class="btn-group gap-2">
                             <button class="btn btn-primary btn-sm rounded-circle p-2 show-article"
                                    data-id="${a.id}" title="Detail"> <i class="fas fa-eye"></i>
                            </button>
                              <button class="btn btn-info btn-sm rounded-circle p-2 toggle-status"
                                    data-id="${a.id}" title="Ubah Status">
                                <i class="fas fa-exchange-alt"></i>
                            </button>
                           <button class="btn btn-warning btn-sm rounded-circle p-2 edit-article"
                                    data-id="${a.id}" title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-danger btn-sm rounded-circle p-2 delete-article" data-id="${a.id}" title="Hapus"><i class="fas fa-trash"></i></button>
                        </div>
                    </td>
                </tr>`;
        });

        $('#article-body').html(html);
    }

    /* ----- pagination ul ----- */
    function renderPagination(lastPage) {
        let html = '';
        if (lastPage > 1) {
            for (let i = 1; i <= lastPage; i++) {

                const isActive = i === currentPage ? 'active' : '';
                const txtWhite = i === currentPage ? 'text-white' : '';

                html += `
                    <li class="page-item ${isActive}">
                        <a href="#"
                        class="page-link page-number ${txtWhite}"
                        data-page="${i}">
                        ${i}
                        </a>
                    </li>`;
            }
        }
        $('#pagination').html(html);
    }
});
</script>

<script>
$(function () {

    /* ──────────────────────────────────────
       Inisialisasi Quill
       ────────────────────────────────────── */
    const quillEdit = new Quill('#editor-edit', {
        theme: 'snow',
        placeholder: 'Edit konten…'
    });

    /* ──────────────────────────────────────
       STATE
       ────────────────────────────────────── */
    let fotoLama = [];           // URL foto lama
    let filesBaru = [];          // FileList baru
    let currentArticleId = null; // ID artikel yg sedang diedit

    /* ──────────────────────────────────────
       BUKA MODAL EDIT
       ────────────────────────────────────── */
    $(document).on('click', '.edit-article', function () {

        currentArticleId = $(this).data('id');     // simpan ID

        $.get("{{ url('admin/article-kilau/article/show') }}/" + currentArticleId)
          .done(res => {
              // isi form
              $('#edit-id').val(res.id);
              $('#edit-title').val(res.title);
              $('#edit-author').val(res.author);
              quillEdit.root.innerHTML = res.content;

              // reset preview
              fotoLama  = res.photos;
              filesBaru = [];
              $('#edit-photo-input').val('');
              renderPreview();

              $('#editArticleModal').modal({backdrop:'static'}).modal('show');
          })
          .fail(() => Swal.fire('Error', 'Gagal memuat data.', 'error'));
    });

    /* ──────────────────────────────────────
       PILIH FOTO BARU
       ────────────────────────────────────── */
    $('#edit-photo-input').on('change', function () {
        filesBaru = [...this.files];
        renderPreview();
    });

    /* ──────────────────────────────────────
       SUBMIT UPDATE
       ────────────────────────────────────── */
    $('#edit-article-form').on('submit', function (e) {
        e.preventDefault();

        const id = currentArticleId || $('#edit-id').val();
        if (!id) return Swal.fire('Error', 'ID artikel kosong.', 'error');

        // sinkronkan Quill → input hidden
        $('#edit-content').val(quillEdit.root.innerHTML);

        const fd = new FormData(this);
        fd.append('_method', 'PUT');                // spoof PUT (route Anda PUT)

        $.ajax({
            url : "{{ url('admin/article-kilau/article/update') }}/" + id,
            type: 'POST',
            data: fd,
            processData:false,
            contentType:false,
            success: res => {
                // tampilkan alert dulu
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil',
                    text:  res.message,
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => {
                    // $('#editArticleModal').modal('hide');
                    // fetchArticles(currentPage, currentSearch); 
                    location.reload();
                });
            },
            error: () => Swal.fire('Error', 'Gagal memperbarui.', 'error')
        });
    });

    /* ──────────────────────────────────────
       TUTUP MODAL (tombol Batal)
       ────────────────────────────────────── */
    $(document).on('click', '.force-modal-close',
        () => $('#editArticleModal').modal('hide'));

    /* ──────────────────────────────────────
       HELPER PREVIEW FOTO
       ────────────────────────────────────── */
    function renderPreview() {
        const box = $('#edit-photo-preview').empty();
        const css = { width:150, height:'auto', objectFit:'cover',
                      borderRadius:6, border:'1px solid #ddd', margin:4 };

        // foto lama
        fotoLama.forEach(src => $('<img>', {src, css}).appendTo(box));

        // foto baru
        filesBaru.forEach(f => {
            if (!f.type.startsWith('image/')) return;
            const r = new FileReader();
            r.onload = e => $('<img>', {src:e.target.result, css}).appendTo(box);
            r.readAsDataURL(f);
        });
    }
});
</script>


<script>
    
   // tombol mata
    $(document).on('click', '.show-article', function () {
        const id  = $(this).data('id');
        const url = "{{ url('admin/article-kilau/article/show') }}/" + id;

        $.get(url, res => {
            $('#modal-judul').text(res.title);
            $('#modal-author').text(res.author ?? '-');
            $('#modal-konten').html(res.content);

            // gambar carousel
            const wrap   = $('#modal-images').empty();
            const images = res.photos.length
                        ? res.photos
                        : ['{{ asset('assets_admin/img/noimage.jpg') }}'];

            images.forEach((src, i) => wrap.append(`
                <div class="carousel-item ${i === 0 ? 'active' : ''}">
                    <img src="${src}" class="d-block w-100">
                </div>`));

            $('#showArticleModal').modal('show');   // id baru
        }).fail(() =>
            Swal.fire('Error', 'Gagal mengambil detail article.', 'error')
        );
    });

    $(document).on('click', '.force-modal-close', function () {
        $('#showArticleModal').modal('hide');
    });

    /* tutup juga dengan ESC (kalau ada problem event) */
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') $('#showArticleModal').modal('hide');
    });

</script>
@endsection
